import os
import sys
import numpy as np
import pandas as pd
from Formula_Evolve import *


def initFormulaDict():
    FormulaDict = dict()
    FormulaDict["Op2"] = "EF - gp_div(EP,(EP + NP + 1))"
    FormulaDict["Tarantula"] = "gp_div(gp_div(EF,(EF + NF )),(gp_div(EF,(EF + NF )) + gp_div(EP,(EP + NP))))"
    FormulaDict["SBI"] = "gp_div(EF,(EF + EP))"
    FormulaDict["Ochiai"] = "gp_div(EF, gp_sqrt((EF + EP) * (EF + NF)))"
    FormulaDict["Jaccard"] = "gp_div(EF, (EF + EP + NF))"
    FormulaDict["Ochiai2"] = "gp_div((EF * NP),gp_sqrt((EF+EP) * (NF+NP) * (EF+NP) * (EP+NF)))"
    FormulaDict["Kulczynski1"] = "gp_div(EF,(NF + EP ))"
    FormulaDict["Dstar2"] = "gp_div((EF * EF), (NF + EP ))"
    FormulaDict["Ample"] = "gp_sub(gp_div(EF,(EF+NF)),gp_div(EP,(EP+NP)))"
    FormulaDict["Wong1"] = "EF"
    FormulaDict["Wong2"] = "EF-EP"
    FormulaDict["DStar"] = "gp_div(EF,(EP+NF))"
    FormulaDict["GP13"] = "gp_mul(EF,gp_add(1,gp_div(1,gp_add(gp_mul(2,EP),EF))))"
    FormulaDict["GP02"] = "gp_mul(2,gp_add(EF,gp_add(gp_sqrt(EP+NP),gp_sqrt(EP))))"
    FormulaDict["GP03"] = "gp_sqrt(gp_sub(gp_mul(EF,EF),gp_sqrt(EP)))"
    FormulaDict["GP19"] = "gp_mul(EF,gp_add((EP-EF),(NF-NP)))"
    FormulaDict["Wong3"] = "EP if np.all(EP<2) else 2+0.1*(EP-2) if np.all(EP>2) and np.all(EP<=10) else 2.8+0.001*(EP-10)"




    return FormulaDict
#print(initFormulaDict())

def computeExamScores(evaluationVersionDict,gpFormulaDict,vFaultLocation,vStatementCount,FaultVersionsDict):
    FormulaDict = initFormulaDict()
    metricNameList = FormulaDict.viewkeys()
    MetricResultDict = dict()
    numofFormula = len(gpFormulaDict)
    numofEvaluationVersions = len(evaluationVersionDict['0'])
    # the last column is average data
    gpMatrix = np.zeros((numofFormula, numofEvaluationVersions+1))
    for metric_i in metricNameList:
        MetricResultDict[metric_i] = np.zeros((numofFormula, numofEvaluationVersions+1))

    for i in range(0,numofFormula):
        print i
        evaluationVersions = evaluationVersionDict[str(i)]
        examlist = []
        examlistDict = dict()

        for metric_i in metricNameList:
            examlistDict[metric_i] = []

        for k in range(0,len(evaluationVersions)):
            spectrum = FaultVersionsDict[str(evaluationVersions[k])]
            EP = spectrum[:, 0]
            EF = spectrum[:, 1]
            NP = spectrum[:, 2]
            NF = spectrum[:, 3]

            gpF = gpFormulaDict[str(i)]
            susp_v = eval(gpF)
            sortedSusp_v = -np.sort(-susp_v)
            faultLocation = int(vFaultLocation[evaluationVersions[k]]) #Fault Location
            susForFault = susp_v[faultLocation]
            tieCount = np.where(sortedSusp_v == susForFault)
            LastTie = tieCount[0].max() + 1  # the last index of a tie of faulty statement
            faultPosinRank = LastTie
            examScore = (faultPosinRank / vStatementCount[evaluationVersions[k]]) * 100
            gpMatrix[i][k] = examScore
            examlist.append(examScore)

            for metric_i in metricNameList:
                susF = FormulaDict[metric_i]
                susp_v = eval(susF)
                sortedSusp_v = -np.sort(-susp_v)
                susForFault = susp_v[faultLocation]
                tieCount = np.where(sortedSusp_v == susForFault)
                LastTie = tieCount[0].max() + 1  # the last index of a tie of faulty statement (Best Rank)
                faultPosinRank = LastTie
                examScore = (faultPosinRank / vStatementCount[evaluationVersions[k]]) * 100
                resultMatrix = MetricResultDict[metric_i]
                resultMatrix[i][k] = examScore
                examlistDict[metric_i].append(examScore)

        avgScore = np.mean(examlist)
        gpMatrix[i][len(evaluationVersions)] = avgScore

        for metric_i in metricNameList:
            avgScore = np.mean(examlistDict[metric_i])
            resultMatrix = MetricResultDict[metric_i]
            resultMatrix[i][len(evaluationVersions)] = avgScore

    return [gpMatrix,MetricResultDict]


def readGPFormulas(dataFile):
    gpFormulaDict = dict()
    gpFormulaFile = open(dataFile, 'r')
    i=0
    formulas = gpFormulaFile.readlines()
    for gpformula in formulas:
        gpFormulaDict[str(i)] = gpformula.strip()
        i = i + 1
    gpFormulaFile.close()

    return gpFormulaDict


#load n history sample versions and generate the rest N versions for evaluation
def genEvaluationVersion(dataFile):
    evaluationVersionDict = dict()
    allVersions = range(0, len(os.listdir("C:\data_directory")))
    i = 0
    versionSamplesFile = open(dataFile, 'r')
    samples = versionSamplesFile.readlines()
    for oneSample in samples:
        oneSample = oneSample.strip('\n[] ').replace(', ',',').split(",")
        gpSampleVersion = map(int,oneSample)
        evaluationVersion = list(set(allVersions).difference(set(gpSampleVersion)))
        evaluationVersionDict[str(i)] = evaluationVersion
        i = i + 1
    versionSamplesFile.close()
    return evaluationVersionDict


def saveExamResult(outputPath, gpMatrix, MetricResultDict):
    metricNameList = MetricResultDict.viewkeys()

    outputFolder = os.path.join(outputPath, "compare")
    if os.path.exists(outputFolder) is False:
        os.mkdir(outputFolder)


    outputGP = os.path.join(outputFolder, "SBFL.csv")
    np.savetxt(outputGP, gpMatrix, delimiter=',')

    for metric_i in metricNameList:
        tempfile = os.path.join(outputFolder, metric_i+".csv")
        np.savetxt(tempfile, MetricResultDict[metric_i], delimiter=',')


if __name__ == "__main__":
    # dataPath = sys.argv[1]
    outputPath = "C:\location_where_you_want_to_sto_the_result"
    evaluationVersionDict = genEvaluationVersion("C:\version_sample_directory")
    gpFormulaDict = readGPFormulas("C:\location_of_the_generated_formulas")
    dataFiles = all_path("C:\location_of_all_the_files")
    vFaultLocation, vStatementCount, FaultVersionsDict = readCSV(dataFiles)
    gpMatrix, MetricResultDict = computeExamScores(evaluationVersionDict, gpFormulaDict, vFaultLocation,
                                                   vStatementCount, FaultVersionsDict)
    saveExamResult(outputPath, gpMatrix, MetricResultDict)